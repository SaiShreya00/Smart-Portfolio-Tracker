import os
import pandas as pd
import yfinance as yf

def fetch_ticker(ticker='AAPL', period='1y', interval='1d'):
    try:
        df = yf.download(ticker, period=period, interval=interval, progress=False)
        df = df.reset_index()
        return df[['Date','Open','High','Low','Close','Adj Close','Volume']]
    except Exception:
        path = os.path.join(os.path.dirname(__file__),'..','sample_data','sample_stocks.csv')
        return pd.read_csv(path, parse_dates=['Date'])

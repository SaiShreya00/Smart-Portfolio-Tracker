# Smart Portfolio Tracker

Finance + Machine Learning project with stock forecasting, financial indicators,
and automated Python pipelines.

Run:
pip install -r requirements.txt
python main.py

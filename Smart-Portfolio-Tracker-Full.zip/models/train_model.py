import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import joblib

def feature_engineer(df):
    df = df.copy()
    df['Returns'] = df['Adj Close'].pct_change().fillna(0)
    df['MA5'] = df['Adj Close'].rolling(5).mean().fillna(method='bfill')
    df['MA10'] = df['Adj Close'].rolling(10).mean().fillna(method='bfill')
    df['Volatility'] = df['Returns'].rolling(10).std().fillna(0)
    df['Target'] = df['Adj Close'].shift(-1)
    df = df.dropna()
    return df

def train(df):
    df_fe = feature_engineer(df)
    X = df_fe[['Adj Close','MA5','MA10','Volatility']].values
    y = df_fe['Target'].values
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,shuffle=False)
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    score = model.score(X_test,y_test)
    joblib.dump(model, 'models/price_model.joblib')
    return score
